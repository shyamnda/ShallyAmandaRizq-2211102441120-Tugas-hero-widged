package com.example.navigasi_hero_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
